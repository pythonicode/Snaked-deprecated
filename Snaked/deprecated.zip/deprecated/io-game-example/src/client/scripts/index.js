// Script for drawing the game

initCanvas();

let canvas = document.getElementById("game");
let screen = canvas.getContext("2d");

let x = 10;

let lastTime = 0;

screen.fillStyle = '#f00';

redraw(lastTime);

// Fill Canvas to Window Size
function initCanvas(){
  $('#game').attr("width",$(window).width());
  $('#game').attr("height",$(window).height());
}


function redraw(timestamp){
  let deltaTime = timestamp - lastTime;



  if(deltaTime > 25){
    screen.clearRect(x - 1, 24, 16, 16);
    screen.fillRect(x + 4, 24, 16, 16);
    x += 5;
    lastTime = timestamp;
  }

  requestAnimationFrame(redraw);
}
